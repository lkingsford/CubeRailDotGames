import { EmuBayRailwayCompany as EmuBayRailwayCompany_0 } from "./emu-bay-railway-company-1"
const games = [EmuBayRailwayCompany_0];
export default games